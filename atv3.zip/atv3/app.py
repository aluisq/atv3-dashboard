import streamlit as st
import plotly.graph_objects as go
import pandas as pd
import numpy as np

# Definir o modo wide
# Definir o modo wide e o tema branco
st.set_page_config(
    layout="wide",
    page_title="Relatos Consumidores - 2022.2 - 2024",
    page_icon="📊",
    initial_sidebar_state="expanded"
)

# Adicionando uma imagem (logo) na barra lateral
st.sidebar.image("./assets/logo.jpg", use_container_width=True)

# Dados fornecidos
agrupamento_notas_regiao = {'Norte': {'1-2': 3059, '3': 661, '4-5': 5436}, 'Nordeste': {'1-2': 14615, '3': 2452, '4-5': 21614}, 'Centro-Oeste': {'1-2': 9124, '3': 1428, '4-5': 12040}, 'Sudeste': {'1-2': 43017, '3': 6462, '4-5': 48257}, 'Sul': {'1-2': 14845, '3': 2415, '4-5': 18385}}

empresas_por_regiao = {
    "Centro-Oeste": {
        "Latam Airlines (Tam)": 1849,
        "Hurb - Hotel Urbano": 1134,
        "Serasa Experian ": 1101,
        "Gol Linhas Aéreas": 905,
        "Azul Linhas Aéreas": 672,
        "Tim": 620,
        "Smiles": 583,
        "123 Milhas": 544,
        "Vivo - Telefônica": 518,
        "Claro Celular": 508
    },
    "Nordeste": {
        "Latam Airlines (Tam)": 2662,
        "Serasa Experian ": 1994,
        "Gol Linhas Aéreas": 1279,
        "Tim": 1160,
        "Azul Linhas Aéreas": 1107,
        "Caixa Econômica Federal": 781,
        "Samsung": 774,
        "Banco do Brasil": 771,
        "Smiles": 754,
        "Vivo - Telefônica": 748
    },
    "Norte": {
        "Latam Airlines (Tam)": 950,
        "Serasa Experian ": 659,
        "Azul Linhas Aéreas": 467,
        "Gol Linhas Aéreas": 406,
        "123 Milhas": 252,
        "Smiles": 215,
        "Tim": 214,
        "Banco do Brasil": 212,
        "Hurb - Hotel Urbano": 184,
        "Claro Celular": 183
    },
    "Sudeste": {
        "Hurb - Hotel Urbano": 7493,
        "Latam Airlines (Tam)": 5429,
        "Serasa Experian ": 4467,
        "Vivo - Telefônica": 2597,
        "Gol Linhas Aéreas": 2377,
        "Tim": 2319,
        "Mercado Livre": 2166,
        "Banco Itaú Unibanco": 1852,
        "Azul Linhas Aéreas": 1818,
        "iFood": 1817
    },
    "Sul": {
        "Latam Airlines (Tam)": 2512,
        "Hurb - Hotel Urbano": 2213,
        "Tim": 1592,
        "Serasa Experian ": 1342,
        "Gol Linhas Aéreas": 1074,
        "Vivo - Telefônica": 870,
        "Azul Linhas Aéreas": 844,
        "Caixa Econômica Federal": 793,
        "123 Milhas": 760,
        "Mercado Livre": 678
    }
}

# Criando um seletor de páginas
pagina = st.sidebar.selectbox("Selecione uma página:", ["Principal", "Centro-Oeste", "Nordeste", "Norte", "Sudeste", "Sul"])

# Exibindo o conteúdo conforme a seleção
if pagina in ["Centro-Oeste", "Nordeste", "Norte", "Sudeste", "Sul"]:

    # Criar duas colunas (imagem na esquerda, título na direita)
    col_titulo, col_imagem = st.columns([1, 5], gap="small") 

    # Adicionar imagem na primeira coluna
    with col_titulo:
        st.title(f"{pagina}")  # Exibir o título na direita

    # Adicionar título na segunda coluna
    with col_imagem:

        if pagina == "Centro-Oeste":
            st.image("./assets/centro-oeste.png", width=120)  # Ajuste o caminho e tamanho da imagem

        elif pagina == "Nordeste":
            st.image("./assets/nordeste.png", width=120)  # Ajuste o caminho e tamanho da imagem

        elif pagina == "Norte":
            st.image("./assets/norte.png", width=120)  # Ajuste o caminho e tamanho da imagem
        
        elif pagina == "Sudeste":
            st.image("./assets/sudeste.png", width=120)  # Ajuste o caminho e tamanho da imagem

        elif pagina == "Sul":
            st.image("./assets/sul.png", width=120)  # Ajuste o caminho e tamanho da imagem

        else:
            st.image("./assets/no-image.jpeg", width=120)  # Ajuste o caminho e tamanho da imagem


    # Espaçamento para duas linhas
    st.markdown("<br><br><br><br>", unsafe_allow_html=True)  # Adiciona 2 quebras de linha (espaço extra)


   # Dados do agrupamento de notas para a região selecionada
    dados = agrupamento_notas_regiao[pagina]

    # Calcular o total geral de todas as notas
    total_geral = sum(dados.values())

    # Container para os gráficos de donut
    with st.container():
        col1, col2, col3 = st.columns([1, 1, 1])  # Dividindo a área horizontal em 3 colunas

    # Função para criar um gráfico de donut com a fração correta
    def criar_donut(valor, cor, total_geral):
        porcentagem = (valor / total_geral) * 100  # Cálculo da porcentagem
        return go.Figure(go.Pie(
            labels=[f"{valor} ({porcentagem:.1f}%)", "Outras Notas"],  # Exibir valor e percentual
            values=[valor, total_geral - valor],  # O valor e o restante
            hole=0.4,  # Tamanho do buraco do donut
            hoverinfo="label+percent",  # Exibir percentual no hover
            textinfo="label",  # Exibir o valor e percentual dentro do donut
            showlegend=False,  # Remover a legenda
            marker=dict(colors=[cor, "#d3d3d3"]),  # Cor principal e cinza claro para o restante
            textfont=dict(size=30)  # Tamanho da fonte do texto dentro do gráfico
        ))

    # Exemplo de uso nos gráficos:
    with col1:
        st.markdown("<h4 style='text-align: center;'>Notas 1-2</h4>", unsafe_allow_html=True)
        fig_donut_1_2 = criar_donut(dados['1-2'], "red", total_geral)
        fig_donut_1_2.update_layout(template="plotly_dark", margin=dict(t=0))
        st.plotly_chart(fig_donut_1_2, use_container_width=True)

    with col2:
        st.markdown("<h4 style='text-align: center;'>Notas 3</h4>", unsafe_allow_html=True)
        fig_donut_3 = criar_donut(dados['3'], "orange", total_geral)
        fig_donut_3.update_layout(template="plotly_dark", margin=dict(t=0))
        st.plotly_chart(fig_donut_3, use_container_width=True)

    with col3:
        st.markdown("<h4 style='text-align: center;'>Notas 4-5</h4>", unsafe_allow_html=True)
        fig_donut_4_5 = criar_donut(dados['4-5'], "green", total_geral)
        fig_donut_4_5.update_layout(template="plotly_dark", margin=dict(t=0))
        st.plotly_chart(fig_donut_4_5, use_container_width=True)


    # Gráfico de barras para as empresas
    empresas = empresas_por_regiao[pagina]
    empresas_nome = list(empresas.keys())
    empresas_valor = list(empresas.values())

    # Definir a escala de cores (do mais forte para o mais fraco)
    cor_inicial = '#505780'
    fig_barras = go.Figure(go.Bar(
        x=empresas_nome,
        y=empresas_valor,
        text=empresas_valor,
        textposition='auto',
        textfont=dict(size=30),  # Ajusta o tamanho do texto nas barras
        marker=dict(
            color=empresas_valor,  # Aplica a cor com base nos valores
            colorscale=[[0, cor_inicial], [1, '#DD3C20']],  # Definindo o gradiente de cores
            colorbar=dict(title="Número de Relatos")  # Título da barra de cores
        )
    ))

    # Ajustando o layout para garantir que o gráfico seja centralizado
    fig_barras.update_layout(
        title=f"Empresas de {pagina}",
        title_font=dict(size=30),  # Tamanho do texto do título
        xaxis_title="Empresa",
        yaxis_title="Número de Relatos",
        xaxis_title_font=dict(size=35),  # Tamanho do texto do rótulo do eixo X
        yaxis_title_font=dict(size=35),  # Tamanho do texto do rótulo do eixo Y
        xaxis=dict(tickfont=dict(size=20)),  # Ajusta o tamanho do texto dos nomes das empresas no eixo X
        template="plotly_dark",
        showlegend=False,
        margin=dict(l=40, r=40, t=40, b=40),  # Ajusta as margens para centralizar o gráfico
        height=600,  # Define uma altura para o gráfico
    )

    # Exibe o gráfico no Streamlit com container width ajustado
    st.plotly_chart(fig_barras, use_container_width=True)



else:
    st.title("Total de Relatos por Região")
    
    
    # Espaçamento para duas linhas
    st.markdown("<br><br><br><br>", unsafe_allow_html=True)  # Adiciona 2 quebras de linha (espaço extra)
    
    
    # Somar os valores por região
    totais_por_regiao = {regiao: sum(estados.values()) for regiao, estados in agrupamento_notas_regiao.items()}


    # Paleta de cores fornecida
    cores_paleta = ['#FFC613', '#FFDA61', '#FCF8E8', '#ABB7FF', '#4761FF'];




    # Se você tem mais regiões do que cores na paleta, você pode repetir a paleta para garantir que ela tenha cores suficientes
    num_regioes = len(totais_por_regiao)
    cores_repetidas = (cores_paleta * ((num_regioes // len(cores_paleta)) + 1))[:num_regioes]

    # Gráfico de barras para o total de relatos por região
    fig = go.Figure(data=[go.Bar(
        x=list(totais_por_regiao.keys()),  # Eixo X com os nomes das regiões
        y=list(totais_por_regiao.values()),  # Eixo Y com o total de relatos
        marker=dict(
            color=cores_repetidas,  # Aplicar as cores da paleta
        ),
        opacity=0.8,  # Transparência das barras
        text=list(totais_por_regiao.values()),  # Mostrar os valores nas barras
        hoverinfo="text"  # Exibir valores ao passar o mouse
    )])

    fig.update_layout(
        title="",
        title_font=dict(size=40),  # Aumenta o tamanho do título
        xaxis_title="Regiões",
        yaxis_title="Total de Relatos",
        xaxis_title_font=dict(size=30),  # Aumenta o tamanho do texto do eixo X
        yaxis_title_font=dict(size=30),  # Aumenta o tamanho do texto do eixo Y
        xaxis=dict(
            tickangle=45,
            tickfont=dict(size=25)  # Aumenta o tamanho dos valores do eixo X
        ),
        yaxis=dict(
            tickfont=dict(size=25)  # Aumenta o tamanho dos valores do eixo Y
        ),
        barmode="group",
        template="plotly_dark",
        height=500,
        showlegend=False,
        margin=dict(t=50, b=50),
    )

    # Atualizando os textos dentro das barras
    fig.update_traces(textfont=dict(size=18))  # Aumenta o tamanho do texto dentro das barras

    # Exibindo o gráfico no Streamlit
    st.plotly_chart(fig, use_container_width=True)
